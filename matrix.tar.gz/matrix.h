#ifndef __MATRIX_H
#define __MATRIX_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int i,j,n;

double MAT[3][3] = {{6,15,55},{15,55,225},{55,225,979}};
double L[3][3] = {0};
double L_TRANS[3][3] = {0};
double R1[3][3] = {0};
double R2[3][3] = {0};
double R3[3][3] = {0};
double R4[3][3] = {0};
double R5[3][3] = {0};
double MAT_INV1[3][3] = {0};
double MAT_INV2[3][3] = {0};
double MAT_INV3[3][3] = {0};

double RES_T[3][3] = {0};
double RES[3][3] = {0};

void multi_mat(double (*A)[3], double (*B)[3], double (*R)[3])
{
	int q,w,e;

	for(q=0;q<3;q++)
	{
		for(w=0;w<3;w++)
		{
			for(e=0;e<3;e++)
				R[q][w] += A[q][e]*B[e][w];
		}
	}
}

void trans_mat(double (*L)[3], double (*L_TRANS)[3])
{
	int q,w;

	for(q=0;q<3;q++)
	{
		for(w=0;w<3;w++)
		{
			L_TRANS[w][q] = L[q][w];
		}
	}
}

void chol()
{
	int k;
	double L_TEMP = 0;
	
	if(j==0)
		L[i][0] = MAT[i][0] / L[0][0];
	else
	{
		for(k=0; k<=j-1; k++)
			L_TEMP += L[i-1][k] * L[i][k];

		L[i][j] = (MAT[i][j] - L_TEMP) / L[j][j];
	}
}

void opp_chol()
{
	int k;
	double L_TEMP = 0;

	if(i==0)
		L[0][0] = sqrt(MAT[0][0]);
	else
	{
		for(j=0; j<=i-1; j++)
			L_TEMP += pow(L[i][j], 2);
	}
		
		L[i][i] = sqrt(MAT[i][i] - L_TEMP);
}

double mat_det(double (*mat)[3])
{
	return mat[0][0]*(mat[1][1]*mat[2][2] - mat[1][2]*mat[2][1]) 
		+ mat[0][1]*(mat[1][2]*mat[2][0] - mat[1][0]*mat[2][2]) 
		+ mat[0][2]*(mat[1][0]*mat[2][1] - mat[1][1]*mat[2][0]);
}

void mat_adj(double (*mat)[3], double (*res)[3])
{
	res[0][0] = mat[1][1]*mat[2][2] - mat[1][2]*mat[2][1];
	res[0][1] = mat[1][2]*mat[2][0] - mat[1][0]*mat[2][2];
	res[0][2] = mat[1][0]*mat[2][1] - mat[1][1]*mat[2][0];
	res[1][0] = mat[0][2]*mat[2][1] - mat[0][1]*mat[2][2];
	res[1][1] = mat[0][0]*mat[2][2] - mat[0][2]*mat[2][0];
	res[1][2] = mat[0][1]*mat[2][0] - mat[0][0]*mat[2][1];
	res[2][0] = mat[0][1]*mat[1][2] - mat[0][2]*mat[1][1];
	res[2][1] = mat[0][2]*mat[1][0] - mat[0][0]*mat[1][2];
	res[2][2] = mat[0][0]*mat[1][1] - mat[0][1]*mat[1][0];
}

void mat_inverse(double (* mat)[3], double (* RES_T)[3], double (* RES)[3])
{
	int i,j;
	float det_A = mat_det(mat);

	mat_adj(mat, RES_T);

	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
			RES_T[i][j] /= det_A;

	trans_mat(RES_T, RES);
}

void print_mat(double (*RES)[3])
{
	int q,w;

	for(q=0;q<3;q++)
	{
		for(w=0;w<3;w++)
		{
			printf("%f	", RES[q][w]);
		}
		printf("\n");
	}
}

#endif
