#include "matrix.h"

int i,j,n;

int main(void)
{
	int q,w;

	printf("MAT = \n");
	print_mat(MAT);
	
	for(i=0;i<3;i++)
	{
		for(j=0;j<=i;j++)
		{
			if(j > i)
				break;

			if(i==j)
				opp_chol();
			else	
				chol();
			
		}
	}

	trans_mat(L, L_TRANS);

	mat_inverse(L, RES_T, R1);
	mat_inverse(L_TRANS, RES_T, R2);
	
	multi_mat(R2, R1, R3);
	multi_mat(L, L_TRANS, R4);
	multi_mat(R4,R3,R5);

	printf("\nL = \n");
	print_mat(L);

	printf("\nL_TRANS = \n");
	print_mat(L_TRANS);

	printf("\nL*L_TRANS = \n");
	print_mat(R4);

	printf("\n(L*L_TRANS)_INVERSE = \n");
	print_mat(R3);

	printf("\nMAT * MAT_INVERSE = \n");
	print_mat(R5);
	
	return 0;
}

